import { supabase } from '../lib/supabase';
import { circleMethodRoundRobin, pickBracketSize, makeKnockoutPairs } from '../utils/scheduling';

// ============================================================
// matchService
// CRUD matchs + génération auto du planning + saisie de score arbitre
// ============================================================

function fromDb(row) {
  if (!row) return null;
  return {
    id: row.id,
    tournamentId: row.tournament_id,
    pool: row.pool,
    phase: row.phase,
    knockoutRound: row.knockout_round,
    knockoutIndex: row.knockout_index,
    round: row.round,
    home: row.home_team_id || row.home_slot, // unifié pour le front : id ou "slot:..." ou "winner:..."
    away: row.away_team_id || row.away_slot,
    homeLabel: row.home_label,
    awayLabel: row.away_label,
    field: row.field,
    time: row.match_time,
    referee: row.referee,
    scoreHome: row.score_home,
    scoreAway: row.score_away,
    status: row.status,
    fairplayHome: row.fairplay_home,
    fairplayAway: row.fairplay_away,
  };
}

// Découpe la propriété 'home'/'away' du front en 2 colonnes db (team_id ou slot)
function teamRefToDb(value) {
  if (!value) return { id: null, slot: null };
  if (typeof value === 'string' && (value.startsWith('slot:') || value.startsWith('winner:') || value.startsWith('loser:'))) {
    return { id: null, slot: value };
  }
  return { id: value, slot: null };
}

function toDb(m) {
  const out = {};
  if (m.tournamentId !== undefined) out.tournament_id = m.tournamentId;
  if (m.pool !== undefined) out.pool = m.pool;
  if (m.phase !== undefined) out.phase = m.phase;
  if (m.knockoutRound !== undefined) out.knockout_round = m.knockoutRound;
  if (m.knockoutIndex !== undefined) out.knockout_index = m.knockoutIndex;
  if (m.round !== undefined) out.round = m.round;
  if (m.home !== undefined) {
    const { id, slot } = teamRefToDb(m.home);
    out.home_team_id = id;
    out.home_slot = slot;
  }
  if (m.away !== undefined) {
    const { id, slot } = teamRefToDb(m.away);
    out.away_team_id = id;
    out.away_slot = slot;
  }
  if (m.homeLabel !== undefined) out.home_label = m.homeLabel;
  if (m.awayLabel !== undefined) out.away_label = m.awayLabel;
  if (m.field !== undefined) out.field = m.field;
  if (m.time !== undefined) out.match_time = m.time;
  if (m.referee !== undefined) out.referee = m.referee;
  if (m.scoreHome !== undefined) out.score_home = m.scoreHome;
  if (m.scoreAway !== undefined) out.score_away = m.scoreAway;
  if (m.status !== undefined) out.status = m.status;
  if (m.fairplayHome !== undefined) out.fairplay_home = m.fairplayHome;
  if (m.fairplayAway !== undefined) out.fairplay_away = m.fairplayAway;
  return out;
}

// ----- Lectures -----

export async function listByTournament(tournamentId) {
  const { data, error } = await supabase
    .from('matches')
    .select('*')
    .eq('tournament_id', tournamentId)
    .order('match_time', { ascending: true });
  if (error) throw error;
  return (data || []).map(fromDb);
}

// ----- Écritures (organisateur) -----

export async function create(tournamentId, input) {
  const payload = { ...toDb({ ...input, tournamentId }) };
  const { data, error } = await supabase
    .from('matches')
    .insert(payload)
    .select()
    .single();
  if (error) throw error;
  return fromDb(data);
}

export async function update(id, patch) {
  const { data, error } = await supabase
    .from('matches')
    .update(toDb(patch))
    .eq('id', id)
    .select()
    .single();
  if (error) throw error;
  return fromDb(data);
}

export async function remove(id) {
  const { error } = await supabase.from('matches').delete().eq('id', id);
  if (error) throw error;
}

// Décale tous les matchs scheduled de delta minutes
export async function shiftSchedule(tournamentId, deltaMinutes) {
  // On lit, on calcule, on écrit en batch
  const { data, error } = await supabase
    .from('matches')
    .select('id, match_time, status')
    .eq('tournament_id', tournamentId)
    .eq('status', 'scheduled');
  if (error) throw error;
  const updates = (data || [])
    .filter(m => m.match_time)
    .map(m => {
      const [h, mn] = m.match_time.split(':').map(Number);
      const total = Math.max(0, Math.min(24 * 60 - 1, h * 60 + mn + deltaMinutes));
      const newH = Math.floor(total / 60);
      const newM = total % 60;
      return { id: m.id, match_time: `${String(newH).padStart(2, '0')}:${String(newM).padStart(2, '0')}:00` };
    });
  if (updates.length === 0) return;
  // upsert batch
  const { error: e2 } = await supabase.from('matches').upsert(updates);
  if (e2) throw e2;
}

// ----- Saisie de score par un arbitre via le RPC sécurisé -----
// L'arbitre fournit le code arbitre du tournoi pour valider l'écriture
export async function submitScore({ matchId, refereeCode, scoreHome, scoreAway, status, fairplayHome, fairplayAway }) {
  const { data, error } = await supabase.rpc('submit_match_score', {
    p_match_id: matchId,
    p_referee_code: refereeCode,
    p_score_home: scoreHome,
    p_score_away: scoreAway,
    p_status: status,
    p_fairplay_home: fairplayHome ?? null,
    p_fairplay_away: fairplayAway ?? null,
  });
  if (error) throw error;
  return fromDb(data);
}

// ----- Génération automatique du planning -----
// Crée les matchs de poule (round-robin équilibré) + bracket d'élimination si activé.
// Ne touche pas aux matchs déjà joués/en cours.
export async function generateSchedule(tournament, teams) {
  const tournamentId = tournament.id;

  // 1. Récupérer matchs actuels et garder ceux qui ne sont PAS scheduled
  const all = await listByTournament(tournamentId);
  const toKeep = all.filter(m => m.status !== 'scheduled');
  const toDelete = all.filter(m => m.status === 'scheduled').map(m => m.id);

  // Supprimer les anciens matchs scheduled
  if (toDelete.length > 0) {
    const { error } = await supabase
      .from('matches')
      .delete()
      .in('id', toDelete);
    if (error) throw error;
  }

  // 2. Construction des nouveaux matchs en mémoire
  const fields = tournament.fields || ['T1', 'T2', 'T3', 'T4'];
  const matchDur = (tournament.categoryDurations && tournament.categoryDurations[tournament.category])
    || tournament.matchDuration || 12;
  const pause = tournament.breakBetweenMatches ?? 3;
  const slotDur = matchDur + pause;

  const [sh, sm] = (tournament.startTime || '09:00').split(':').map(Number);
  let timeMinutes = sh * 60 + sm;
  let fieldIdx = 0;

  const fmtTime = (mins) => {
    const h = Math.floor(mins / 60);
    const m = mins % 60;
    return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
  };
  const advance = () => {
    fieldIdx++;
    if (fieldIdx >= fields.length) {
      fieldIdx = 0;
      timeMinutes += slotDur;
    }
  };

  const generated = [];
  const pools = [...new Set(teams.map(t => t.pool))].sort();

  // ----- Phase poules -----
  const poolRounds = {};
  pools.forEach(pool => {
    const poolTeams = teams.filter(t => t.pool === pool);
    poolRounds[pool] = circleMethodRoundRobin(poolTeams);
  });
  const maxRounds = Math.max(0, ...pools.map(p => poolRounds[p].length));

  for (let r = 0; r < maxRounds; r++) {
    pools.forEach(pool => {
      const round = poolRounds[pool][r];
      if (!round) return;
      round.forEach(([a, b]) => {
        generated.push({
          tournament_id: tournamentId,
          pool,
          phase: 'pool',
          round: r + 1,
          home_team_id: a.id,
          away_team_id: b.id,
          status: 'scheduled',
          match_time: fmtTime(timeMinutes) + ':00',
          field: fields[fieldIdx],
          referee: '',
        });
        advance();
      });
    });
  }

  // ----- Phase finale -----
  if (tournament.hasKnockout && pools.length > 0) {
    const topN = tournament.knockoutFromTopN || 2;
    const qualifiedCount = pools.length * topN;
    const bracketSize = pickBracketSize(qualifiedCount);

    if (bracketSize >= 2) {
      // Espace logistique avant le bracket
      if (fieldIdx > 0) { timeMinutes += slotDur; fieldIdx = 0; }
      timeMinutes += slotDur;

      const qualified = [];
      pools.forEach(p => {
        for (let rank = 1; rank <= topN; rank++) {
          qualified.push({ slot: `${p}#${rank}`, label: `${rank}${rank === 1 ? 'er' : 'e'} P.${p}` });
        }
      });
      const seeds = qualified.slice(0, bracketSize);
      const pairs = makeKnockoutPairs(seeds, pools, topN);
      const firstLabel = bracketSize === 16 ? 'r16' : bracketSize === 8 ? 'qf' : bracketSize === 4 ? 'sf' : 'final';

      // 1er tour
      const tempIds = []; // on va re-utiliser ces matchs pour les rounds suivants
      pairs.forEach((pair, idx) => {
        const tempId = 'tmp_' + idx;
        tempIds.push(tempId);
        generated.push({
          _tempId: tempId,
          tournament_id: tournamentId,
          phase: 'knockout',
          knockout_round: firstLabel,
          knockout_index: idx,
          round: 1,
          home_slot: 'slot:' + pair[0].slot,
          away_slot: 'slot:' + pair[1].slot,
          home_label: pair[0].label,
          away_label: pair[1].label,
          status: 'scheduled',
          match_time: fmtTime(timeMinutes) + ':00',
          field: fields[fieldIdx],
          referee: '',
        });
        advance();
      });

      // Tours suivants : insertion en chaîne par ID retourné, donc on insère
      // par étapes pour pouvoir référencer les UUID réels
      // On passe par une insertion intermédiaire pour récupérer les vrais IDs
      // Pour rester simple ici, on stocke les IDs des matchs précédents en mémoire
      // après une insertion par lot.

      // Insertion du premier tour pour obtenir les IDs réels
      const firstRound = generated.filter(g => g._tempId);
      const cleanedFirst = firstRound.map(({ _tempId, ...rest }) => rest);

      // Insère tout ce qu'on a pour l'instant (poule + 1er tour ko)
      const poolMatches = generated.filter(g => !g._tempId && !g._roundLevel);
      const allFirst = [...poolMatches, ...cleanedFirst];

      const { data: insertedFirst, error: e1 } = await supabase
        .from('matches')
        .insert(allFirst)
        .select();
      if (e1) throw e1;

      // Récupère les UUID des matchs du 1er tour KO
      const koFirstByIndex = {};
      (insertedFirst || []).forEach(m => {
        if (m.phase === 'knockout' && m.knockout_round === firstLabel) {
          koFirstByIndex[m.knockout_index] = m.id;
        }
      });

      // Tours suivants
      let size = bracketSize / 2;
      let prevIds = pairs.map((_, i) => koFirstByIndex[i]);

      while (size >= 1) {
        if (fieldIdx > 0) { timeMinutes += slotDur; fieldIdx = 0; }
        timeMinutes += slotDur;

        const label = size === 8 ? 'qf' : size === 4 ? 'sf' : size === 2 ? 'final' : 'r' + (size * 2);
        const newRound = [];
        for (let i = 0; i < size; i++) {
          newRound.push({
            tournament_id: tournamentId,
            phase: 'knockout',
            knockout_round: label,
            knockout_index: i,
            round: 1,
            home_slot: 'winner:' + prevIds[i * 2],
            away_slot: 'winner:' + prevIds[i * 2 + 1],
            home_label: 'Vainqueur ' + i * 2,
            away_label: 'Vainqueur ' + (i * 2 + 1),
            status: 'scheduled',
            match_time: fmtTime(timeMinutes) + ':00',
            field: fields[fieldIdx],
            referee: '',
          });
          advance();
        }

        // Petite finale après les demis
        if (size === 2 && prevIds.length === 2) {
          newRound.push({
            tournament_id: tournamentId,
            phase: 'knockout',
            knockout_round: '3rd',
            knockout_index: 0,
            round: 1,
            home_slot: 'loser:' + prevIds[0],
            away_slot: 'loser:' + prevIds[1],
            home_label: 'Perdant demi 1',
            away_label: 'Perdant demi 2',
            status: 'scheduled',
            match_time: fmtTime(timeMinutes) + ':00',
            field: fields[fieldIdx],
            referee: '',
          });
          advance();
        }

        const { data: insertedRound, error: eR } = await supabase
          .from('matches')
          .insert(newRound)
          .select();
        if (eR) throw eR;

        const byIndex = {};
        (insertedRound || []).forEach(m => {
          if (m.knockout_round === label) byIndex[m.knockout_index] = m.id;
        });
        prevIds = Array.from({ length: size }, (_, i) => byIndex[i]);
        size = size / 2;
      }

      return; // tout a été inséré au fur et à mesure
    }
  }

  // Si pas de phase finale, on insère juste les matchs de poule en bloc
  if (generated.length > 0) {
    const cleaned = generated.map(({ _tempId, _roundLevel, ...rest }) => rest);
    const { error } = await supabase.from('matches').insert(cleaned);
    if (error) throw error;
  }
}

export const matchService = {
  listByTournament,
  create,
  update,
  remove,
  shiftSchedule,
  submitScore,
  generateSchedule,
};
