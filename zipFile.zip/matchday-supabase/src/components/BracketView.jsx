import React from 'react';
import { Trophy, Sparkles } from 'lucide-react';
import { Crest } from './Crest';
import { getDisplayTeam } from '../utils/standings';
import { knockoutRoundLabel } from '../utils/scheduling';
import { styles } from '../styles/styles';

// ============================================================
// BracketView — affichage colonné des matchs de phase finale
// ============================================================
export function BracketView({ knockoutMatches, teams, matches, standings, onMatchTap }) {
  const roundOrder = ['r16', 'qf', 'sf', 'final', '3rd'];
  const grouped = {};
  knockoutMatches.forEach(m => {
    const r = m.knockoutRound || 'unknown';
    if (!grouped[r]) grouped[r] = [];
    grouped[r].push(m);
  });
  Object.keys(grouped).forEach(r => {
    grouped[r].sort((a, b) => (a.knockoutIndex || 0) - (b.knockoutIndex || 0));
  });

  const presentRounds = roundOrder.filter(r => grouped[r] && grouped[r].length > 0);

  if (presentRounds.length === 0) {
    return (
      <div style={styles.emptyState}>
        <Trophy size={28} color="#475569" />
        <span>Aucun match de phase finale généré pour l'instant.</span>
      </div>
    );
  }

  return (
    <>
      <div style={styles.bracketContainer}>
        <div style={styles.bracketGrid}>
          {presentRounds.map(roundKey => (
            <div key={roundKey} style={styles.bracketColumn}>
              <div style={styles.bracketColumnLabel}>
                {knockoutRoundLabel(roundKey)}
              </div>
              {grouped[roundKey].map(m => (
                <BracketMatchCard
                  key={m.id}
                  match={m}
                  teams={teams}
                  matches={matches}
                  standings={standings}
                  onTap={() => onMatchTap(m)}
                />
              ))}
            </div>
          ))}
        </div>
      </div>
      <div style={{ ...styles.helpBox, marginTop: 16 }}>
        <Sparkles size={12} color="#a78bfa" />
        <span>Les équipes se placent automatiquement dès que les matchs précédents sont validés.</span>
      </div>
    </>
  );
}

function BracketMatchCard({ match, teams, matches, standings, onTap }) {
  const home = getDisplayTeam('home', match, teams, matches, standings);
  const away = getDisplayTeam('away', match, teams, matches, standings);
  const isLive = match.status === 'live';
  const isDone = match.status === 'validated';
  const homeWin = isDone && match.scoreHome > match.scoreAway;
  const awayWin = isDone && match.scoreAway > match.scoreHome;

  return (
    <button
      onClick={onTap}
      style={{
        ...styles.bracketMatch,
        ...(isLive ? styles.bracketMatchLive : {}),
        ...(isDone ? styles.bracketMatchDone : {}),
      }}
    >
      <div
        style={{
          ...styles.bracketTeam,
          ...(homeWin ? styles.bracketTeamWin : {}),
          ...(isDone && !homeWin ? styles.bracketTeamLose : {}),
        }}
      >
        <Crest team={home} size="sm" />
        <span style={styles.bracketName}>{home.name}</span>
        {match.scoreHome !== null && match.scoreHome !== undefined && (
          <span style={styles.bracketScore}>{match.scoreHome}</span>
        )}
      </div>
      <div
        style={{
          ...styles.bracketTeam,
          ...(awayWin ? styles.bracketTeamWin : {}),
          ...(isDone && !awayWin ? styles.bracketTeamLose : {}),
        }}
      >
        <Crest team={away} size="sm" />
        <span style={styles.bracketName}>{away.name}</span>
        {match.scoreAway !== null && match.scoreAway !== undefined && (
          <span style={styles.bracketScore}>{match.scoreAway}</span>
        )}
      </div>
      <div style={styles.bracketMeta}>
        <span>{match.field || '?'} · {(match.time || '—').slice(0, 5)}</span>
        {isLive && <span style={{ color: '#22d3ee' }}>● LIVE</span>}
        {isDone && <span style={{ color: '#34d399' }}>FT</span>}
      </div>
    </button>
  );
}
