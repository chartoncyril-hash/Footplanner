import React from 'react';
import { Activity, ChevronRight, Clock, Hash, Crown, ShieldCheck } from 'lucide-react';
import { Crest } from './Crest';
import { getDisplayTeam } from '../utils/standings';
import { styles } from '../styles/styles';

// ============================================================
// Primitives UI réutilisables
// Pas de logique métier ici, juste de l'affichage paramétré
// ============================================================

export function StatTile({ label, value, color, pulse }) {
  return (
    <div style={styles.statTile}>
      <div style={{ ...styles.statValue, color }}>
        {value}
        {pulse && value > 0 && <span style={{ ...styles.pulseDot, background: color }} />}
      </div>
      <div style={styles.statLabel}>{label}</div>
    </div>
  );
}

export function SectionHeader({ icon: Icon, title, accent = '#22d3ee', badge }) {
  return (
    <div style={styles.sectionHeader}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <div style={{ ...styles.sectionIconBox, background: accent + '15', borderColor: accent + '40' }}>
          <Icon size={13} color={accent} strokeWidth={2.5} />
        </div>
        <span style={styles.sectionTitle}>{title}</span>
        {badge !== undefined && (
          <span style={{ ...styles.sectionBadge, background: accent }}>{badge}</span>
        )}
      </div>
    </div>
  );
}

export function QuickAction({ icon: Icon, label, onClick, color }) {
  return (
    <button onClick={onClick} style={styles.quickAction}>
      <div style={{ ...styles.quickIcon, background: color + '15', borderColor: color + '40' }}>
        <Icon size={18} color={color} strokeWidth={2.2} />
      </div>
      <span style={styles.quickLabel}>{label}</span>
    </button>
  );
}

export function PageHeader({ title, subtitle, icon: Icon, accent = '#22d3ee' }) {
  return (
    <div style={styles.pageHeader}>
      <div style={{ ...styles.pageHeaderIcon, background: accent + '15', borderColor: accent + '40' }}>
        <Icon size={18} color={accent} strokeWidth={2.2} />
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={styles.pageHeaderTitle}>{title}</div>
        {subtitle && <div style={styles.pageHeaderSub}>{subtitle}</div>}
      </div>
    </div>
  );
}

// ============================================================
// LiveMatchCard — match en cours, gros score visible
// ============================================================
export function LiveMatchCard({ match, teams, matches, standings, onTap }) {
  const home = getDisplayTeam('home', match, teams, matches, standings);
  const away = getDisplayTeam('away', match, teams, matches, standings);
  return (
    <button onClick={onTap} style={styles.liveCard}>
      <div style={styles.liveTopRow}>
        <div style={styles.livePill}>
          <span style={styles.livePulse} />
          <span style={{ fontSize: 9, fontWeight: 800, letterSpacing: 1.5 }}>EN DIRECT</span>
        </div>
        <div style={styles.liveField}>
          <Hash size={9} /> {match.field}
        </div>
      </div>
      <div style={styles.liveScore}>
        <div style={styles.liveTeam}>
          <Crest team={home} size="md" />
          <span style={styles.liveTeamName}>{home.short}</span>
        </div>
        <div style={styles.liveScoreNum}>
          {match.scoreHome ?? 0}
          <span style={{ color: '#475569', margin: '0 8px' }}>—</span>
          {match.scoreAway ?? 0}
        </div>
        <div style={{ ...styles.liveTeam, flexDirection: 'row-reverse' }}>
          <Crest team={away} size="md" />
          <span style={styles.liveTeamName}>{away.short}</span>
        </div>
      </div>
    </button>
  );
}

// ============================================================
// UpcomingMatchCard — match à venir, heure visible
// ============================================================
export function UpcomingMatchCard({ match, teams, matches, standings, onTap }) {
  const home = getDisplayTeam('home', match, teams, matches, standings);
  const away = getDisplayTeam('away', match, teams, matches, standings);
  return (
    <button onClick={onTap} style={styles.upcomingCard}>
      <div style={styles.upcomingTime}>
        <Clock size={11} color="#94a3b8" />
        <span style={{ fontSize: 12, fontWeight: 800, color: '#cbd5e1', fontFamily: "'JetBrains Mono', monospace" }}>
          {(match.time || '').slice(0, 5)}
        </span>
      </div>
      <div style={styles.upcomingMid}>
        <div style={styles.upcomingTeams}>
          <Crest team={home} size="sm" />
          <span style={styles.upcomingTeamName}>{home.short}</span>
          <span style={{ fontSize: 10, color: '#475569', margin: '0 4px' }}>vs</span>
          <Crest team={away} size="sm" />
          <span style={styles.upcomingTeamName}>{away.short}</span>
        </div>
        <div style={styles.upcomingMeta}>
          <Hash size={9} /> {match.field}
          {match.pool && <span> · P.{match.pool}</span>}
        </div>
      </div>
      <ChevronRight size={14} color="#475569" />
    </button>
  );
}

// ============================================================
// MatchListCard — utilisée dans la liste complète
// ============================================================
export function MatchListCard({ match, teams, matches, standings, onTap }) {
  const home = getDisplayTeam('home', match, teams, matches, standings);
  const away = getDisplayTeam('away', match, teams, matches, standings);
  const isLive = match.status === 'live';
  const isDone = match.status === 'validated';

  let stateColor = '#94a3b8';
  let stateLabel = (match.time || '').slice(0, 5) || '—';
  if (isLive) { stateColor = '#22d3ee'; stateLabel = 'EN DIRECT'; }
  else if (isDone) { stateColor = '#34d399'; stateLabel = 'TERMINÉ'; }

  return (
    <button onClick={onTap} style={styles.matchListCard}>
      <div style={{ ...styles.matchListLeft, color: stateColor }}>
        {isLive && <span style={styles.livePulse} />}
        <span style={{ fontSize: 9, fontWeight: 800, letterSpacing: 1 }}>{stateLabel}</span>
      </div>

      <div style={styles.matchListMid}>
        <div style={styles.matchListSide}>
          <Crest team={home} size="sm" />
          <span style={styles.matchListName}>{home.short}</span>
        </div>
        <div style={styles.matchListScore}>
          {(isLive || isDone)
            ? <span style={{ color: stateColor, fontWeight: 800 }}>
                {match.scoreHome ?? 0} - {match.scoreAway ?? 0}
              </span>
            : <span style={{ color: '#475569' }}>vs</span>}
        </div>
        <div style={{ ...styles.matchListSide, flexDirection: 'row-reverse' }}>
          <Crest team={away} size="sm" />
          <span style={styles.matchListName}>{away.short}</span>
        </div>
      </div>

      <div style={styles.matchListRight}>
        <Hash size={9} /> {match.field}
      </div>
    </button>
  );
}
