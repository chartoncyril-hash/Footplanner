import React, { useState } from 'react';
import {
  Calendar, Sparkles, Plus, Edit3, Lock, Filter,
  Hash, Goal as Whistle, Download, FileText, X,
} from 'lucide-react';
import { Crest } from './Crest';
import { PageHeader } from './MatchCards';
import { MatchEditor } from './MatchEditor';
import { getDisplayTeam } from '../utils/standings';
import { knockoutRoundLabel } from '../utils/scheduling';
import { pdfService } from '../services/pdfService';
import { styles } from '../styles/styles';

// ============================================================
// ScheduleView — calendrier des matchs (édition manuelle + auto)
// ============================================================
export function ScheduleView({
  tournament, teams, matches, standings, role,
  createMatch, updateMatch, removeMatch,
  generateSchedule, askConfirm, closeConfirm,
  setSelectedMatch, setView,
}) {
  const [editing, setEditing] = useState(null); // null | 'new' | match
  const [filterPool, setFilterPool] = useState('all');
  const [generating, setGenerating] = useState(false);
  const [error, setError] = useState('');
  const [pdfMenuOpen, setPdfMenuOpen] = useState(false);
  const [exporting, setExporting] = useState(false);

  const canManage = role === 'organizer';
  const pools = [...new Set(teams.map(t => t.pool))].sort();
  const fields = tournament.fields || ['T1', 'T2', 'T3', 'T4'];

  if (!canManage) {
    return (
      <div style={{ paddingBottom: 130 }}>
        <PageHeader title="Calendrier" icon={Calendar} accent="#34d399" />
        <div style={styles.lockedBox}>
          <Lock size={28} color="#64748b" />
          <div style={{ fontSize: 14, fontWeight: 700, color: '#cbd5e1', marginTop: 8 }}>
            Accès restreint
          </div>
          <div style={{ fontSize: 12, color: '#64748b', marginTop: 4 }}>
            Seul l'organisateur peut configurer le calendrier
          </div>
        </div>
      </div>
    );
  }

  const saveMatch = async (data) => {
    setError('');
    try {
      if (data.id) {
        await updateMatch(data.id, data);
      } else {
        await createMatch({
          ...data,
          scoreHome: null,
          scoreAway: null,
          status: 'scheduled',
          fairplayHome: null,
          fairplayAway: null,
        });
      }
      setEditing(null);
    } catch (e) {
      setError(e.message || "Erreur d'enregistrement.");
    }
  };

  const deleteMatch = (id) => {
    const m = matches.find(x => x.id === id);
    const wasPlayed = m && m.status !== 'scheduled';
    askConfirm({
      title: wasPlayed ? 'Match déjà joué' : 'Supprimer ce match ?',
      message: wasPlayed
        ? 'Ce match a déjà été joué ou est en cours. La suppression effacera son score.'
        : 'Cette action retire le match du calendrier.',
      confirmLabel: 'Supprimer',
      danger: true,
      onConfirm: async () => {
        try {
          await removeMatch(id);
          setEditing(null);
        } catch (e) {
          setError(e.message);
        } finally {
          closeConfirm();
        }
      },
    });
  };

  const handleGenerate = () => {
    askConfirm({
      title: 'Générer le planning ?',
      message: teams.length < 2
        ? 'Il faut au moins 2 équipes pour générer un planning.'
        : 'Toutes les rencontres de poules + phase finale seront créées automatiquement. Les matchs scheduled actuels seront remplacés (les matchs déjà joués / en cours sont conservés).',
      confirmLabel: 'Générer',
      onConfirm: async () => {
        closeConfirm();
        if (teams.length < 2) return;
        setGenerating(true);
        setError('');
        try {
          await generateSchedule(tournament, teams);
        } catch (e) {
          setError(e.message || 'Erreur lors de la génération.');
        } finally {
          setGenerating(false);
        }
      },
    });
  };

  // Filtre par poule + tri par heure
  let filtered = filterPool === 'all'
    ? matches
    : filterPool === 'knockout'
      ? matches.filter(m => m.phase === 'knockout')
      : matches.filter(m => m.pool === filterPool && m.phase !== 'knockout');

  filtered = [...filtered].sort((a, b) => {
    const ta = (a.time || '99:99').slice(0, 5);
    const tb = (b.time || '99:99').slice(0, 5);
    return ta.localeCompare(tb);
  });

  // Export PDF
  const exportPdf = async (kind, pool) => {
    setExporting(true);
    setError('');
    try {
      if (kind === 'full') {
        await pdfService.downloadSchedulePdf(tournament, teams, matches);
      } else if (kind === 'summary') {
        await pdfService.downloadSummaryPdf(tournament, teams, matches);
      } else if (kind === 'pool') {
        await pdfService.downloadPoolPdf(tournament, teams, matches, pool);
      }
      setPdfMenuOpen(false);
    } catch (e) {
      setError(e.message || 'Erreur lors de la génération du PDF.');
    } finally {
      setExporting(false);
    }
  };

  return (
    <div style={{ paddingBottom: 130 }}>
      <PageHeader
        title="Calendrier"
        subtitle={`${matches.length} matchs programmés`}
        icon={Calendar}
        accent="#34d399"
      />

      {/* Actions */}
      <div style={styles.scheduleActions}>
        <button
          onClick={handleGenerate}
          disabled={generating || teams.length < 2}
          style={{ ...styles.btnGenerate || styles.btnPrimary, opacity: (generating || teams.length < 2) ? 0.5 : 1 }}
        >
          <Sparkles size={14} /> {generating ? 'Génération…' : 'GÉNÉRER AUTO'}
        </button>
        <button
          onClick={() => setEditing('new')}
          style={styles.btnSecondary}
        >
          <Plus size={14} /> AJOUTER
        </button>
      </div>

      {/* Bouton PDF (en pleine largeur si on a des matchs) */}
      {matches.length > 0 && (
        <button
          onClick={() => setPdfMenuOpen(true)}
          disabled={exporting}
          style={{
            ...styles.btnSecondary,
            width: '100%',
            marginBottom: 10,
            background: 'rgba(167,139,250,0.08)',
            borderColor: 'rgba(167,139,250,0.3)',
            color: '#a78bfa',
            opacity: exporting ? 0.5 : 1,
          }}
        >
          <Download size={14} /> {exporting ? 'Génération…' : 'EXPORTER EN PDF (AFFICHAGE TERRAIN)'}
        </button>
      )}

      {error && (
        <div style={{ ...styles.fieldError, marginBottom: 10, textAlign: 'center' }}>{error}</div>
      )}

      {/* Filtre par poule */}
      <div style={styles.filterBar}>
        <button
          onClick={() => setFilterPool('all')}
          style={{ ...styles.filterChip, ...(filterPool === 'all' ? styles.filterChipActive : {}) }}
        >
          TOUS
        </button>
        {pools.map(p => (
          <button
            key={p}
            onClick={() => setFilterPool(p)}
            style={{ ...styles.filterChip, ...(filterPool === p ? styles.filterChipActive : {}) }}
          >
            P.{p}
          </button>
        ))}
        {matches.some(m => m.phase === 'knockout') && (
          <button
            onClick={() => setFilterPool('knockout')}
            style={{ ...styles.filterChip, ...(filterPool === 'knockout' ? styles.filterChipActive : {}) }}
          >
            KO
          </button>
        )}
      </div>

      <div style={styles.cardStack}>
        {filtered.length === 0 && (
          <div style={styles.emptyState}>
            <Calendar size={28} color="#475569" />
            <span>
              Aucun match. Ajoute des équipes puis génère le planning, ou crée un match manuel.
            </span>
          </div>
        )}
        {filtered.map(m => (
          <ScheduleMatchRow
            key={m.id}
            match={m}
            teams={teams}
            matches={matches}
            standings={standings}
            onEdit={() => setEditing(m)}
            onTap={() => { setSelectedMatch(m); setView('match'); }}
          />
        ))}
      </div>

      {editing && (
        <MatchEditor
          match={editing === 'new' ? null : editing}
          teams={teams}
          fields={fields}
          pools={pools}
          onSave={saveMatch}
          onDelete={editing !== 'new' ? () => deleteMatch(editing.id) : null}
          onCancel={() => setEditing(null)}
        />
      )}

      {pdfMenuOpen && (
        <PdfExportMenu
          tournament={tournament}
          pools={pools}
          hasKnockout={matches.some(m => m.phase === 'knockout')}
          exporting={exporting}
          onExport={exportPdf}
          onClose={() => setPdfMenuOpen(false)}
        />
      )}
    </div>
  );
}

// ============================================================
// PdfExportMenu — modale plein écran pour choisir le type d'export
// ============================================================
function PdfExportMenu({ tournament, pools, hasKnockout, exporting, onExport, onClose }) {
  return (
    <div style={styles.fullscreenSheet}>
      <div style={styles.sheetHead}>
        <button onClick={onClose} style={styles.sheetBack}>
          <X size={18} />
        </button>
        <span style={styles.sheetTitle}>Exporter en PDF</span>
        <div style={{ width: 38 }} />
      </div>

      <div style={styles.sheetBody}>
        <div style={{ ...styles.helpBox, marginBottom: 16 }}>
          <FileText size={12} color="#a78bfa" />
          <span>
            Génère un PDF prêt à imprimer pour affichage sur les terrains. Format A4, lisible à distance.
          </span>
        </div>

        {/* Planning complet (par poule, multi-pages) */}
        <PdfChoice
          icon={FileText}
          color="#22d3ee"
          title="Planning complet"
          desc={`${pools.length} poule${pools.length > 1 ? 's' : ''}${hasKnockout ? ' + phase finale' : ''}, une page par poule. Idéal pour distribuer aux équipes.`}
          onClick={() => onExport('full')}
          disabled={exporting}
        />

        {/* Résumé compact 1 page */}
        <PdfChoice
          icon={FileText}
          color="#a78bfa"
          title="Résumé compact"
          desc="Tous les matchs sur une seule page, triés par heure. Pratique pour la table de marque."
          onClick={() => onExport('summary')}
          disabled={exporting}
        />

        {/* Une poule en particulier */}
        {pools.length > 0 && (
          <>
            <div
              style={{
                fontSize: 9,
                fontWeight: 800,
                letterSpacing: 1.5,
                color: '#64748b',
                marginTop: 16,
                marginBottom: 6,
              }}
            >
              PAR POULE
            </div>
            {pools.map(pool => (
              <PdfChoice
                key={pool}
                icon={FileText}
                color="#34d399"
                title={`Poule ${pool}`}
                desc="Affichage dédié pour le terrain de cette poule."
                onClick={() => onExport('pool', pool)}
                disabled={exporting}
                small
              />
            ))}
          </>
        )}
      </div>
    </div>
  );
}

function PdfChoice({ icon: Icon, color, title, desc, onClick, disabled, small }) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      style={{
        display: 'flex',
        alignItems: 'center',
        gap: 12,
        padding: small ? 12 : 14,
        marginBottom: 8,
        width: '100%',
        background: color + '08',
        border: `1px solid ${color}33`,
        borderRadius: 10,
        cursor: disabled ? 'not-allowed' : 'pointer',
        opacity: disabled ? 0.5 : 1,
        textAlign: 'left',
      }}
    >
      <div
        style={{
          width: 36,
          height: 36,
          borderRadius: 9,
          background: color + '15',
          border: `1px solid ${color}55`,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          flexShrink: 0,
        }}
      >
        <Icon size={16} color={color} />
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 13, fontWeight: 800, color: '#f1f5f9' }}>{title}</div>
        <div style={{ fontSize: 11, color: '#94a3b8', marginTop: 2, lineHeight: 1.3 }}>{desc}</div>
      </div>
      <Download size={14} color={color} />
    </button>
  );
}

function ScheduleMatchRow({ match, teams, matches, standings, onEdit, onTap }) {
  const home = getDisplayTeam('home', match, teams, matches, standings);
  const away = getDisplayTeam('away', match, teams, matches, standings);
  const isKnockout = match.phase === 'knockout';

  return (
    <div style={styles.matchListCard}>
      <button
        onClick={onTap}
        style={{ ...styles.matchListLeft, color: '#94a3b8', background: 'transparent', border: 'none', padding: 0 }}
      >
        <span style={{ fontSize: 9, fontWeight: 800, letterSpacing: 1 }}>
          {(match.time || '—').slice(0, 5)}
        </span>
      </button>

      <button
        onClick={onTap}
        style={{ ...styles.matchListMid, background: 'transparent', border: 'none', padding: 0, cursor: 'pointer' }}
      >
        <div style={styles.matchListSide}>
          <Crest team={home} size="sm" />
          <span style={styles.matchListName}>{home.short}</span>
        </div>
        <div style={styles.matchListScore}>
          {match.status === 'validated'
            ? <span style={{ color: '#34d399', fontWeight: 800 }}>{match.scoreHome} - {match.scoreAway}</span>
            : match.status === 'live'
              ? <span style={{ color: '#22d3ee', fontWeight: 800 }}>{match.scoreHome ?? 0} - {match.scoreAway ?? 0}</span>
              : <span style={{ color: '#475569' }}>vs</span>}
        </div>
        <div style={{ ...styles.matchListSide, flexDirection: 'row-reverse' }}>
          <Crest team={away} size="sm" />
          <span style={styles.matchListName}>{away.short}</span>
        </div>
      </button>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 2, alignItems: 'flex-end' }}>
        <span style={styles.matchListRight}>
          <Hash size={9} /> {match.field}
        </span>
        {isKnockout && (
          <span style={{ fontSize: 8, color: '#f59e0b', fontWeight: 800 }}>
            {knockoutRoundLabel(match.knockoutRound)}
          </span>
        )}
      </div>

      {!isKnockout && (
        <button
          onClick={onEdit}
          style={{
            ...styles.btnSmall,
            padding: '6px 8px',
            marginLeft: 4,
          }}
        >
          <Edit3 size={11} />
        </button>
      )}
    </div>
  );
}
