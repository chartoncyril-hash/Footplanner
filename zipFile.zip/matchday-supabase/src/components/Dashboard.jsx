import React from 'react';
import {
  Sparkles, Calendar, MapPin, Activity, Clock, Zap, Trophy, Users, Star,
  Timer, ArrowLeft, ChevronRight,
  Goal as Whistle,
} from 'lucide-react';
import { StatTile, SectionHeader, QuickAction, LiveMatchCard, UpcomingMatchCard } from './MatchCards';
import { styles } from '../styles/styles';

// ============================================================
// Dashboard — écran d'accueil après onboarding
// Reçoit ctx (App.jsx) avec :
//   - tournament, teams, matches, standings (data via hooks)
//   - role (rôle d'affichage local)
//   - setView, setSelectedMatch (navigation)
//   - shiftSchedule (action async via service)
// ============================================================
export function Dashboard({
  tournament, teams, matches, standings, role,
  setView, setSelectedMatch,
  shiftSchedule,
}) {
  const liveMatches = matches.filter(m => m.status === 'live');
  const upcomingMatches = matches.filter(m => m.status === 'scheduled').slice(0, 4);
  const completedCount = matches.filter(m => m.status === 'validated').length;
  const totalCount = matches.length;
  const progress = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;

  const isOrganizer = role === 'organizer';
  const canFollow = role === 'spectator' || role === 'coach';

  const handleShift = async (delta) => {
    try {
      await shiftSchedule(delta);
    } catch (e) {
      console.error('Shift failed', e);
    }
  };

  return (
    <div style={{ paddingBottom: 130 }}>
      {/* Hero */}
      <section style={styles.hero}>
        <div style={styles.heroGrid}>
          <div style={styles.heroLabel}>
            <Sparkles size={11} /> EN COURS
          </div>
          <div style={styles.heroTitle}>{tournament.name}</div>
          <div style={styles.heroMeta}>
            {tournament.date && (
              <span>
                <Calendar size={11} /> {new Date(tournament.date).toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long' })}
              </span>
            )}
            {tournament.location && (
              <span><MapPin size={11} /> {tournament.location}</span>
            )}
          </div>
          {totalCount > 0 && (
            <div style={styles.heroProgress}>
              <div style={styles.progressTrack}>
                <div style={{ ...styles.progressFill, width: `${progress}%` }} />
              </div>
              <div style={styles.progressMeta}>
                <span style={{ color: '#22d3ee', fontWeight: 800 }}>{completedCount}</span>
                <span style={{ color: '#64748b' }}>/ {totalCount} matchs joués · {progress}%</span>
              </div>
            </div>
          )}
        </div>
        <div style={styles.heroAccent} />
      </section>

      {/* Stats */}
      <section style={styles.statRow}>
        <StatTile label="EN DIRECT" value={liveMatches.length} color="#22d3ee" pulse />
        <StatTile label="TERMINÉS" value={completedCount} color="#34d399" />
        <StatTile label="ÉQUIPES" value={teams.length} color="#a78bfa" />
        <StatTile label="POULES" value={[...new Set(teams.map(t => t.pool))].length} color="#f59e0b" />
      </section>

      {/* Avance/retard (organisateur) */}
      {isOrganizer && (
        <section style={styles.section}>
          <SectionHeader icon={Timer} title="Décaler le planning" accent="#fb7185" />
          <div style={styles.adjustPanel}>
            <button onClick={() => handleShift(-5)} style={styles.adjustBtn}>
              <ArrowLeft size={12} /> -5 min
            </button>
            <button onClick={() => handleShift(-10)} style={styles.adjustBtn}>
              -10 min
            </button>
            <div style={styles.adjustLabel}>
              <Timer size={14} color="#fb7185" />
              <span>Avance / Retard</span>
            </div>
            <button onClick={() => handleShift(10)} style={styles.adjustBtn}>
              +10 min
            </button>
            <button onClick={() => handleShift(5)} style={styles.adjustBtn}>
              +5 min <ChevronRight size={12} />
            </button>
          </div>
          <div style={{ fontSize: 10, color: '#64748b', textAlign: 'center', marginTop: 6 }}>
            Décale tous les matchs à venir (ceux joués/en cours sont préservés).
          </div>
        </section>
      )}

      {/* Live */}
      {liveMatches.length > 0 && (
        <section style={styles.section}>
          <SectionHeader icon={Activity} title="Matchs en direct" accent="#22d3ee" />
          <div style={styles.cardStack}>
            {liveMatches.map(m => (
              <LiveMatchCard
                key={m.id}
                match={m}
                teams={teams}
                matches={matches}
                standings={standings}
                onTap={() => { setSelectedMatch(m); setView('match'); }}
              />
            ))}
          </div>
        </section>
      )}

      {/* Upcoming */}
      {upcomingMatches.length > 0 && (
        <section style={styles.section}>
          <SectionHeader icon={Clock} title="À venir" accent="#94a3b8" />
          <div style={styles.cardStack}>
            {upcomingMatches.map(m => (
              <UpcomingMatchCard
                key={m.id}
                match={m}
                teams={teams}
                matches={matches}
                standings={standings}
                onTap={() => { setSelectedMatch(m); setView('match'); }}
              />
            ))}
          </div>
        </section>
      )}

      {/* Quick actions */}
      <section style={styles.section}>
        <SectionHeader icon={Zap} title="Raccourcis" accent="#a78bfa" />
        <div style={styles.quickGrid}>
          <QuickAction icon={Trophy} label="Classement live" onClick={() => setView('standings')} color="#f59e0b" />
          <QuickAction icon={Whistle} label="Tous les matchs" onClick={() => setView('matches')} color="#22d3ee" />
          {canFollow && (
            <QuickAction icon={Star} label="Mes équipes" onClick={() => setView('follow')} color="#facc15" />
          )}
          {role !== 'spectator' && (
            <QuickAction icon={Users} label="Équipes" onClick={() => setView('teams')} color="#a78bfa" />
          )}
          {isOrganizer && (
            <>
              <QuickAction icon={Calendar} label="Calendrier" onClick={() => setView('schedule')} color="#34d399" />
              <QuickAction icon={Trophy} label="Archives" onClick={() => setView('archives')} color="#a78bfa" />
            </>
          )}
        </div>
      </section>
    </div>
  );
}
