import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './App';
import { globalCSS } from './styles/styles';

// Injection unique du CSS global
const styleEl = document.createElement('style');
styleEl.textContent = globalCSS;
document.head.appendChild(styleEl);

createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
