import React, { useState, useEffect, useCallback } from 'react';
import { useAuth } from './hooks/useAuth';
import {
  useMyTournaments,
  useTournament,
  useTeams,
  useMatches,
  useStandings,
  useTeamLibrary,
} from './hooks/useTournamentData';
import { useFollowedTeams } from './hooks/useTournamentSecondary';
import { useNotifications } from './hooks/useNotifications';

import { LoadingScreen } from './components/LoadingScreen';
import { AuthScreen } from './components/AuthScreen';
import { OnboardingFlow } from './components/OnboardingFlow';
import { Dashboard } from './components/Dashboard';
import { ArchivesView } from './components/ArchivesView';
import { MatchList } from './components/MatchList';
import { MatchDetail } from './components/MatchDetail';
import { Standings } from './components/Standings';
import { TeamsView } from './components/TeamsView';
import { ScheduleView } from './components/ScheduleView';
import { SettingsView } from './components/SettingsView';
import { RoleSwitcher } from './components/RoleSwitcher';
import { FollowView } from './components/FollowView';
import { TopBar } from './components/TopBar';
import { BottomNav } from './components/BottomNav';
import { AnnouncementBar } from './components/AnnouncementBar';
import { SponsorTicker } from './components/SponsorTicker';
import { ConfirmDialog } from './components/ConfirmDialog';
import { NotifStack } from './components/NotifStack';

// ============================================================
// App.jsx — orchestration de haut niveau
//
// Choix d'architecture :
// - Aucun storage local : tout vient de Supabase via les hooks
// - Aucun appel Supabase ici, uniquement dans les services et hooks
// - L'état "rôle actif" reste local (préférence d'affichage du device)
// - Les composants reçoivent des actions (callbacks) issues des hooks
// ============================================================

export default function App() {
  const { user, loading: authLoading, signOut } = useAuth();

  // Sélection du tournoi actif (côté UI uniquement — n'affecte pas la BDD)
  // - Pour un organisateur : le dernier tournoi 'live' qu'il a créé
  // - Pour un spectateur : tournoi accédé via accessCode
  const [activeTournamentId, setActiveTournamentId] = useState(null);
  const [accessCode, setAccessCode] = useState(null);

  // Rôle d'affichage : organizer | referee | spectator | coach
  const [role, setRole] = useState('spectator');
  // Code arbitre saisi (stocké en sessionStorage uniquement, pas en bdd)
  const [refereeCode, setRefereeCode] = useState(() => {
    try { return sessionStorage.getItem('referee_code') || null; } catch { return null; }
  });

  // Navigation
  const [view, setView] = useState('dashboard');
  const [selectedMatch, setSelectedMatch] = useState(null);
  const [confirmDialog, setConfirmDialog] = useState(null);

  // ----- Données du tournoi actif -----
  const { tournament, loading: tLoading, update: updateTournament, reload: reloadTournament } =
    useTournament({ id: activeTournamentId, accessCode });
  const { teams, loading: teamsLoading, create: createTeam, update: updateTeam, remove: removeTeam, importFromLibrary } =
    useTeams(tournament?.id);
  const { matches, loading: matchesLoading, create: createMatch, update: updateMatch, remove: removeMatch,
          submitScore, shiftSchedule, generateSchedule } = useMatches(tournament?.id);
  const standings = useStandings(teams, matches, tournament);

  // Liste des tournois de l'organisateur connecté
  const { list: myTournaments, create: createTournament, archive: archiveTournament } = useMyTournaments();

  // Bibliothèque persistante
  const { library: teamsLibrary, remove: removeFromLibrary, reload: reloadLibrary } = useTeamLibrary();

  // Équipes suivies par l'utilisateur connecté (badge nav + filtre notifs)
  const { followedIds: followedTeamIds, toggle: toggleFollow } = useFollowedTeams(tournament?.id);

  // Moteur de notifications in-app (toasts)
  const { notifs, dismiss: dismissNotif } = useNotifications({
    matches, tournament, role, followedIds: followedTeamIds,
  });

  // ----- Sélection automatique du tournoi -----
  // Quand l'utilisateur s'authentifie, on charge automatiquement son dernier tournoi live
  useEffect(() => {
    if (!user) {
      setActiveTournamentId(null);
      return;
    }
    if (myTournaments.length > 0 && !activeTournamentId && !accessCode) {
      const live = myTournaments.find(t => t.status === 'live') || myTournaments[0];
      setActiveTournamentId(live.id);
      setRole('organizer');
    }
  }, [user, myTournaments, activeTournamentId, accessCode]);

  // ----- Helpers UI -----
  const askConfirm = useCallback((opts) => setConfirmDialog(opts), []);
  const closeConfirm = useCallback(() => setConfirmDialog(null), []);

  // Onboarding spectateur : saisie du code de tournoi
  const handleAccessCodeSubmit = async (code) => {
    setAccessCode(code);
    setActiveTournamentId(null);
    setRole('spectator');
    setView('dashboard');
  };

  // Saisie du code arbitre
  const handleRefereeCodeSubmit = (code) => {
    if (!tournament || !code) return false;
    if (tournament.refereeCode === code) {
      try { sessionStorage.setItem('referee_code', code); } catch {}
      setRefereeCode(code);
      setRole('referee');
      return true;
    }
    return false;
  };

  // Lock du rôle staff (efface le code arbitre stocké)
  const lockRole = (roleId) => {
    if (roleId === 'referee') {
      try { sessionStorage.removeItem('referee_code'); } catch {}
      setRefereeCode(null);
    }
    setRole('spectator');
  };

  // ----- Création / archivage de tournoi -----
  const startNewTournament = useCallback(async () => {
    const t = await createTournament({ name: 'Nouveau tournoi' });
    setActiveTournamentId(t.id);
    setRole('organizer');
    setView('settings');
    return t;
  }, [createTournament]);

  const closeTournament = useCallback(async () => {
    if (!tournament) return;
    askConfirm({
      title: 'Clôturer le tournoi ?',
      message: `« ${tournament.name} » sera archivé avec son classement et ses résultats.`,
      confirmLabel: 'Archiver',
      onConfirm: async () => {
        await archiveTournament(tournament.id);
        await reloadTournament();
        closeConfirm();
      },
    });
  }, [tournament, archiveTournament, reloadTournament, askConfirm, closeConfirm]);

  // ----- Rendu -----

  if (authLoading) return <LoadingScreen />;

  // Pas connecté = écran d'auth
  // Choix : on impose la connexion à tout le monde (multi-tenant strict).
  // Pour permettre aux spectateurs de visualiser sans compte, on pourrait
  // ajouter ici un bouton "accéder en tant que spectateur" qui demande
  // juste un code de tournoi sans authentification — à condition d'élargir
  // les policies RLS de lecture (déjà 'true' dans le SQL fourni).
  if (!user) {
    return <AuthScreen />;
  }

  // Spectateur sans tournoi sélectionné = onboarding code
  if (!tournament && !tLoading) {
    return (
      <OnboardingFlow
        onAccessCodeSubmit={handleAccessCodeSubmit}
        onCreateTournament={startNewTournament}
        myTournaments={myTournaments}
        onPickTournament={(id) => { setActiveTournamentId(id); setRole('organizer'); }}
      />
    );
  }

  if (tLoading || teamsLoading || matchesLoading) return <LoadingScreen />;

  // Contexte injecté à tous les écrans
  const ctx = {
    // données
    tournament, teams, matches, standings, teamsLibrary, myTournaments,
    // navigation
    view, setView, selectedMatch, setSelectedMatch,
    // rôle
    role, setRole, refereeCode, lockRole,
    // actions tournoi
    updateTournament, closeTournament, startNewTournament,
    // actions équipes
    createTeam, updateTeam, removeTeam, importFromLibrary,
    // bibliothèque
    removeFromLibrary, reloadLibrary,
    // follow
    followedTeamIds, toggleFollow,
    // actions matchs
    createMatch, updateMatch, removeMatch,
    submitScore: (params) => submitScore({ ...params, refereeCode }),
    shiftSchedule, generateSchedule,
    // confirm
    askConfirm, closeConfirm,
    // auth
    signOut, user,
    handleRefereeCodeSubmit,
  };

  return (
    <div className="app">
      <TopBar {...ctx} />
      <AnnouncementBar tournamentId={tournament.id} />

      <main className="main">
        {view === 'dashboard' && <Dashboard {...ctx} />}
        {view === 'standings' && <Standings {...ctx} />}
        {view === 'matches' && <MatchList {...ctx} />}
        {view === 'match' && selectedMatch && <MatchDetail {...ctx} />}
        {view === 'teams' && <TeamsView {...ctx} />}
        {view === 'schedule' && <ScheduleView {...ctx} />}
        {view === 'settings' && <SettingsView {...ctx} />}
        {view === 'roles' && <RoleSwitcher {...ctx} />}
        {view === 'follow' && <FollowView {...ctx} />}
        {view === 'archives' && <ArchivesView {...ctx} setActiveTournament={(id) => { setActiveTournamentId(id); setView('dashboard'); }} />}
      </main>

      <SponsorTicker tournamentId={tournament.id} />
      <BottomNav {...ctx} />

      {confirmDialog && <ConfirmDialog {...confirmDialog} onCancel={closeConfirm} />}
      <NotifStack
        notifs={notifs}
        teams={teams}
        onDismiss={dismissNotif}
        onTap={(matchId) => {
          const m = matches.find(x => x.id === matchId);
          if (m) { setSelectedMatch(m); setView('match'); }
        }}
      />
    </div>
  );
}
