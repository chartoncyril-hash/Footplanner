// ============================================================
// Calcul du classement — logique pure
// ============================================================

export function computeStandings(teams, matches, tournament) {
  const byPool = {};

  teams.forEach(t => {
    if (!byPool[t.pool]) byPool[t.pool] = [];
    const stats = {
      ...t,
      played: 0, won: 0, drawn: 0, lost: 0,
      goalsFor: 0, goalsAgainst: 0, goalDiff: 0,
      points: 0,
      basePoints: 0, bonusPoints: 0, fairplayPoints: 0,
    };

    matches.forEach(m => {
      if (m.status !== 'validated') return;
      if (m.phase && m.phase !== 'pool') return; // exclure les knockouts
      if (m.home !== t.id && m.away !== t.id) return;

      const isHome = m.home === t.id;
      const gf = isHome ? m.scoreHome : m.scoreAway;
      const ga = isHome ? m.scoreAway : m.scoreHome;
      stats.played++;
      stats.goalsFor += gf;
      stats.goalsAgainst += ga;

      if (gf > ga) { stats.won++; stats.basePoints += tournament.scoring.win; }
      else if (gf === ga) { stats.drawn++; stats.basePoints += tournament.scoring.draw; }
      else { stats.lost++; stats.basePoints += tournament.scoring.loss; }

      const fp = isHome ? m.fairplayHome : m.fairplayAway;
      if (tournament.bonuses?.fairplay?.enabled && fp) {
        stats.fairplayPoints += tournament.bonuses.fairplay.points;
      }
      if (tournament.bonuses?.cleanSheet?.enabled && ga === 0) {
        stats.bonusPoints += tournament.bonuses.cleanSheet.points;
      }
    });

    stats.goalDiff = stats.goalsFor - stats.goalsAgainst;
    stats.points = stats.basePoints + stats.bonusPoints + stats.fairplayPoints;
    byPool[t.pool].push(stats);
  });

  Object.keys(byPool).forEach(pool => {
    byPool[pool].sort((a, b) => {
      for (const tb of (tournament.tiebreakers || ['points', 'goalDiff', 'goalsFor'])) {
        if (tb === 'points' && b.points !== a.points) return b.points - a.points;
        if (tb === 'goalDiff' && b.goalDiff !== a.goalDiff) return b.goalDiff - a.goalDiff;
        if (tb === 'goalsFor' && b.goalsFor !== a.goalsFor) return b.goalsFor - a.goalsFor;
      }
      return 0;
    });
  });

  return byPool;
}

// Résolution d'une équipe à partir d'une référence (id direct, slot, winner/loser)
// pour afficher proprement les matchs de phase finale
export function getDisplayTeam(side, match, teams, matches, standings) {
  const ref = side === 'home' ? match.home : match.away;
  const fallbackLabel = side === 'home' ? match.homeLabel : match.awayLabel;

  const direct = teams.find(t => t.id === ref);
  if (direct) return direct;

  if (typeof ref === 'string' && ref.startsWith('slot:')) {
    const [poolName, rankStr] = ref.replace('slot:', '').split('#');
    const rank = parseInt(rankStr) - 1;
    if (standings && standings[poolName]) {
      const poolMatches = matches.filter(m => m.phase === 'pool' && m.pool === poolName);
      const allDone = poolMatches.length > 0 && poolMatches.every(m => m.status === 'validated');
      if (allDone && standings[poolName][rank]) {
        return standings[poolName][rank];
      }
    }
    return makePlaceholder(fallbackLabel || `${rank + 1}${rank === 0 ? 'er' : 'e'} P.${poolName}`);
  }

  if (typeof ref === 'string' && (ref.startsWith('winner:') || ref.startsWith('loser:'))) {
    const isWinner = ref.startsWith('winner:');
    const matchId = ref.split(':')[1];
    const m = matches.find(x => x.id === matchId);
    if (m && m.status === 'validated' && m.scoreHome !== m.scoreAway) {
      const winSide = m.scoreHome > m.scoreAway ? 'home' : 'away';
      const targetSide = isWinner ? winSide : (winSide === 'home' ? 'away' : 'home');
      return getDisplayTeam(targetSide, m, teams, matches, standings);
    }
    return makePlaceholder(fallbackLabel || (isWinner ? 'Vainqueur' : 'Perdant'));
  }

  return makePlaceholder(fallbackLabel || '?');
}

function makePlaceholder(label) {
  return {
    id: '__placeholder__',
    name: label,
    short: '?',
    color: '#475569',
    isPlaceholder: true,
  };
}
